-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 24, 2026 at 08:58 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tmdt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `congty`
--

CREATE TABLE `congty` (
  `idcty` int(10) unsigned NOT NULL auto_increment,
  `tencty` varchar(200) collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(200) collate utf8_unicode_ci NOT NULL,
  `dienthoai` varchar(20) collate utf8_unicode_ci NOT NULL,
  `fax` varchar(20) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idcty`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `congty`
--

INSERT INTO `congty` (`idcty`, `tencty`, `diachi`, `dienthoai`, `fax`) VALUES
(1, 'Công ty TNHH Sony', 'Quận 1, TP.HCM', '0901111111', '0281111111'),
(2, 'Điện máy Xanh', 'Quận 3, TP.HCM', '0902222222', '0282222222'),
(3, 'Thế Giới Di Động', 'Quận 5, TP.HCM', '0903333333', '0283333333'),
(4, 'FPT Shop', 'Quận 7, TP.HCM', '0904444444', '0244444444'),
(5, 'Phong Vũ', 'Quận 10, TP.HCM', '0905555555', '0285555555');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `idsp` int(10) unsigned NOT NULL auto_increment,
  `tensp` varchar(100) collate utf8_unicode_ci NOT NULL,
  `gia` float NOT NULL,
  `mota` text collate utf8_unicode_ci NOT NULL,
  `hinh` varchar(100) collate utf8_unicode_ci NOT NULL,
  `giamgia` float NOT NULL,
  `idcty` int(11) NOT NULL,
  PRIMARY KEY  (`idsp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`idsp`, `tensp`, `gia`, `mota`, `hinh`, `giamgia`, `idcty`) VALUES
(1, 'Tai nghe Sony WH-1000XM4', 6.5e+006, 'Tai nghe chống ồn cao cấp', 'sony_xm4.jpg', 5, 1),
(2, 'Tủ lạnh Samsung Inverter', 1.2e+007, 'Tủ lạnh tiết kiệm điện năng', 'tulanh.jpg', 10, 2),
(3, 'Điện thoại iPhone 15 Pro', 2.8e+007, 'Smartphone cao cấp từ Apple', 'iphone15.jpg', 0, 3),
(4, 'MacBook Air M2', 2.6e+007, 'Laptop mỏng nhẹ, pin trâu', 'macbook_air.jpg', 5, 4),
(5, 'Laptop Asus ROG Strix', 3.2e+007, 'Laptop gaming hiệu năng cao', 'asus_rog.jpg', 15, 5);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `iduser` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(100) collate utf8_unicode_ci NOT NULL,
  `password` varchar(100) collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ten` varchar(20) collate utf8_unicode_ci NOT NULL,
  `phanquyen` int(11) NOT NULL,
  `landangnhapcuoi` date NOT NULL,
  PRIMARY KEY  (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`iduser`, `username`, `password`, `hodem`, `ten`, `phanquyen`, `landangnhapcuoi`) VALUES
(1, 'admin', '123456', 'Nguyễn Văn', 'An', 1, '2026-09-11'),
(2, 'nhanvien1', '123456', 'Trần Thị', 'Bình', 2, '2026-09-11'),
(3, 'nhanvien2', '123456', 'Lê Hoàng', 'Cường', 2, '2026-09-10'),
(4, 'khachhang1', '123456', 'Phạm', 'Dung', 3, '2026-09-09'),
(5, 'khachhang2', '123456', 'Vũ Văn', 'Em', 3, '2026-09-08');
