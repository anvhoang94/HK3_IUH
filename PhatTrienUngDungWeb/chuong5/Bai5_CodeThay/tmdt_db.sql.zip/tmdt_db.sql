-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 24, 2026 at 08:49 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tmdt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `congty`
--

CREATE TABLE `congty` (
  `idcty` int(10) unsigned NOT NULL auto_increment,
  `tencty` varchar(200) character set utf8 collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(200) character set utf8 collate utf8_unicode_ci NOT NULL,
  `dienthoai` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `fax` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idcty`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `congty`
--

INSERT INTO `congty` (`idcty`, `tencty`, `diachi`, `dienthoai`, `fax`) VALUES
(1, 'ABC', 'XYZ', '09091112222', ''),
(2, 'XYZ', '192/ABC', '0909111333', '');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `idsp` int(10) unsigned NOT NULL auto_increment,
  `tensp` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `gia` float NOT NULL,
  `mota` text character set utf8 collate utf8_unicode_ci NOT NULL,
  `hinh` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `giamgia` float NOT NULL,
  `idcty` int(11) NOT NULL,
  PRIMARY KEY  (`idsp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`idsp`, `tensp`, `gia`, `mota`, `hinh`, `giamgia`, `idcty`) VALUES
(1, 'Iphone 16 pro max', 29.99, '', '', 0, 0),
(2, 'Laptop Legion', 34.99, '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `iduser` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `hodem` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ten` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `phanquyen` int(11) NOT NULL,
  `landangnhapcuoi` date NOT NULL,
  PRIMARY KEY  (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `taikhoan`
--

